import mysql from 'mysql';
import express from 'express';
import cors from "cors";

const app = express();

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'mydatabase'
});

app.get("/student", (req, res) => {
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    const sql = "SELECT * FROM student";
    connection.query(sql, (queryError, data) => {
      connection.release();

      if (queryError) {
        console.error('Error executing SQL query:', queryError);
        return res.status(500).json({ error: 'Internal server error' });
      }
      return res.json(data);
    });
  });
});

app.get("/student/:id", (req, res) => {
  const id = req.params.id;

  pool.query("SELECT * FROM student WHERE id = ?", id, (err, data) => {
    if (err) {
      console.error('Error executing SQL query:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    if (data.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    return res.json(data[0]);
  });
});

app.post("/student", (req, res) => {
  const { id, name, email } = req.body;

  if (!id || !name || !email) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = "INSERT INTO student (id, name, email) VALUES (?, ?, ?)";
  pool.query(sql, [id, name, email], (err, result) => {
    if (err) {
      console.error('Error executing SQL query:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
    return res.status(201).json({ message: 'Student created successfully' });
  });
});

app.delete("/student/:id", (req, res) => {
  const id = req.params.id;

  pool.query("DELETE FROM student WHERE id = ?", id, (err, result) => {
    if (err) {
      console.error('Error executing SQL query:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    return res.status(200).json({ message: 'Student deleted successfully' });
  });
});

app.put("/update/:id", (req, res) => {
  const id = req.params.id;
  const { name, email } = req.body; // Destructure name and email directly from req.body

  if (!name || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
  }

  const sql = "UPDATE student SET name = ?, email = ? WHERE id = ?";
  pool.query(sql, [name, email, id], (err, result) => {
      if (err) {
          console.error('Error executing SQL query:', err);
          return res.status(500).json({ error: 'Internal server error' });
      }

      if (result.affectedRows === 0) {
          return res.status(404).json({ error: 'Student not found' });
      }

      return res.status(200).json({ message: 'Student updated successfully' });
  });
});


const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
