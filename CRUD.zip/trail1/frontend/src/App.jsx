import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Student from './Student';
import StudentList from './StudentList';
import ReadStudent from './ReadStudent';
import EditStudent from './EditStudent'; // Add import for EditStudent component

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/Student" element={<Student />} />
          <Route path="/StudentList" element={<StudentList />} />
          <Route path="/edit/:id" element={<EditStudent />} />
          <Route path="/read/:id" element={<ReadStudent />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
