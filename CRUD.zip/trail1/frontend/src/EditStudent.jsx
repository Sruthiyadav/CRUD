import 'bootstrap/dist/css/bootstrap.min.css';
import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

function EditStudent() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [student, setStudent] = useState({
        id: '',
        name: '',
        email: ''
    });

    useEffect(() => {
        // Fetch student details by ID when the component mounts
        axios.get(`http://localhost:3001/student/${id}`)
            .then(res => {
                const { id, name, email } = res.data;
                setStudent({ id, name, email });
            })
            .catch(err => console.error(err));
    }, [id]);

    const handleSubmit = (event) => {
        event.preventDefault();
        const { name, email } = student; // Destructure name and email from student
        axios.put(`http://localhost:3001/update/${id}`, { name, email }) // Send name and email directly
            .then(res => {
                console.log(res);
                navigate('/StudentList');
            })
            .catch(err => console.error(err));
    };
    

    const handleChange = (e) => {
        const { name, value } = e.target;
        setStudent(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    return (
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-50 bg-white rounded p-3">
                <form onSubmit={handleSubmit}>
                    <h2>Update Student</h2>
                    <div className="mb-2">
                        <label htmlFor="id">Student ID</label>
                        <input
                            type="text"
                            id="id"
                            name="id"
                            className="form-control"
                            value={student.id}
                            readOnly
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="name">Student Name</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            className="form-control"
                            value={student.name}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="email">Student Email</label>
                        <input
                            type="text"
                            id="email"
                            name="email"
                            className="form-control"
                            value={student.email}
                            onChange={handleChange}
                        />
                    </div>
                    <button type="submit" className="btn btn-success">Update</button>
                    <Link to="/StudentList" className="btn btn-link ms-2">Cancel</Link>
                </form>
            </div>
        </div>
    );
}

export default EditStudent;
