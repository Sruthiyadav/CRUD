import 'bootstrap/dist/css/bootstrap.min.css';
import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Create() {
    const [id, setid] = useState('');
    const [name, setname] = useState('');
    const [email, setemail] = useState('');
    const navigate = useNavigate();

    function handleSubmit(event) {
        event.preventDefault();
        axios.post('http://localhost:3001/student', {id, name, email})
            .then(res => {
                console.log(res);
                // If the navigation is successful, it should log a message to the console
                navigate('/StudentList');
            })
            .catch(err => console.error(err));
    }

    return (
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-50 bg-white rounded p-3">
                <form onSubmit={handleSubmit}>
                    <h2>Add Student</h2>
                    <div className="mb-2">
                        <label htmlFor="id">Student ID</label>
                        <input 
                            type="text" 
                            id="ID" 
                            placeholder="Enter ID" 
                            className="form-control"
                            value={id}
                            onChange={e => setid(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="name">Student Name</label>
                        <input 
                            type="text" 
                            id="Name" 
                            placeholder="Enter name" 
                            className="form-control"
                            value={name}
                            onChange={e => setname(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="email">Student Email</label>
                        <input 
                            type="text" 
                            id="Email" 
                            placeholder="Enter email" 
                            className="form-control"
                            value={email}
                            onChange={e => setemail(e.target.value)}
                        />
                    </div>
                    <button type="submit" className="btn btn-success">Submit</button>
                    {/* Link to navigate to the homepage */}
                    <Link to="/" className="btn btn-link">Cancel</Link>
                </form>
            </div>
        </div>
    );
}

export default Create;
