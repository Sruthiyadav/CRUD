import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function StudentList() {
    const [students, setStudents] = useState([]);

    useEffect(() => {
        // Fetch students data from the server
        axios.get('http://localhost:3001/student')
            .then(res => {
                setStudents(res.data);
            })
            .catch(err => console.error(err));
    }, []);

    // Function to handle deletion of a student
    const handleDelete = (id) => {
        axios.delete(`http://localhost:3001/student/${id}`)
            .then(res => {
                // Remove the deleted student from the local state
                setStudents(students.filter(student => student.id !== id));
            })
            .catch(err => console.error(err));
    };

    return (
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
        <div className="w-50 bg-white rounded p-3">
            <h2>Student List</h2>
            <div className="d-flex justify-content-end mb-3">
            <Link to="/Student" className="btn btn-primary mb-3">Add Student</Link>
            </div>
            <table className="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {students.map(student => (
                        <tr key={student.id}>
                            <td>{student.id}</td>
                            <td>{student.name}</td>
                            <td>{student.email}</td>
                            <td>
                                <Link to={`/edit/${student.id}`} className="btn btn-sm btn-primary me-2">Edit</Link>
                                <button onClick={() => handleDelete(student.id)} className="btn btn-sm btn-danger me-2">Delete</button>
                                <Link to={`/read/${student.id}`} className="btn btn-sm btn-success">Read</Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        </div>
    );
}

export default StudentList;
